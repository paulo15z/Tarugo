"""
Roteiros e planos de corte calculados a partir do schema Dinabox operacional.

Substituição da lógica antiga baseada em DataFrame CSV/XLS.
Os mesmos critérios de negócio são preservados; a entrada muda de
pd.Series (coluna do CSV) para PartOperacional (Pydantic).
"""
from __future__ import annotations

from apps.integracoes.dinabox.schemas.dinabox_operacional import (
    ModuleOperacional,
    PartOperacional,
)


# ---------------------------------------------------------------------------
# Helpers internos
# ---------------------------------------------------------------------------

def _tem_borda(part: PartOperacional) -> bool:
    """Retorna True se ao menos um lado tem rebordo definido."""
    for edge in (part.edge_left, part.edge_right, part.edge_top, part.edge_bottom):
        if edge and edge.name:
            return True
    return False


def _total_furos(part: PartOperacional) -> int:
    if not part.holes:
        return 0
    return part.holes.total_holes


def _note(part: PartOperacional) -> str:
    return (part.note or "").lower().strip()


def _name(part: PartOperacional) -> str:
    return (part.name or "").lower().strip()


def _module_type(module: ModuleOperacional) -> str:
    return (module.type or "").lower().strip()


# ---------------------------------------------------------------------------
# Roteiro
# ---------------------------------------------------------------------------

def calcular_roteiro_dinabox(part: PartOperacional, module: ModuleOperacional) -> str:
    """
    Calcula o roteiro de fabricação de uma peça a partir dos dados do Dinabox.

    Critérios (equivalentes ao roteiro antigo do CSV):
    - COR  → sempre primeiro
    - DUP  → módulo engrossado (thickened) OU note contém "duplagem"
    - BOR  → peça tem ao menos um edge definido
    - USI  → peça tem furos/rasgos
    - FUR  → sempre após USI quando há furos
    - MCX  → gaveta/caixa (type=drawer, sub-tipo caixa) sem frontal
    - MPE  → porta (type=door) ou frontal de gaveta
    - MAR  → portas, engrossados ou tamponamentos após montagem
    - PIN  → note contém "pintura" ou "_pin_"
    - TAP  → note contém "_tap_"
    - MEL  → note contém "_led_"
    - CQL + EXP → sempre ao final
    """
    note = _note(part)
    name = _name(part)
    part_type = (part.type or "").lower()
    mod_type = _module_type(module)

    tem_borda = _tem_borda(part)
    tem_furo = _total_furos(part) > 0
    tem_duplagem = (
        mod_type == "thickened"
        or "duplagem" in note
        or "encaminhar p/ duplagem" in note
    )
    eh_porta = part_type == "door"
    eh_gaveta = part_type == "drawer"

    # Frontais de gaveta: contra-frente, tampa, basculante
    # Cobre variações: "contra frente", "contrafrente", "contra-frente"
    eh_frontal_gaveta = eh_gaveta and any(
        kw in name
        for kw in (
            "contra frente", "contrafrente", "contra-frente",
            "tampa", "frontal", "basculante",
        )
    )
    # Caixa de gaveta: laterais, fundo, posterior
    eh_caixa_gaveta = eh_gaveta and not eh_frontal_gaveta

    tem_pintura = "_pin_" in note or "pintura" in note
    tem_tapecar = "_tap_" in note or "tapeçar" in note
    tem_eletrica = "_led_" in note or "elétrica" in note or "eletrica" in note
    tem_tamponamento = "tamponamento" in note or "_tamp_" in note

    rota: list[str] = ["COR"]

    if tem_duplagem:
        rota.append("DUP")

    if tem_borda:
        rota.append("BOR")

    if tem_furo:
        rota.append("USI")
        rota.append("FUR")

    if eh_caixa_gaveta and not tem_duplagem:
        rota.append("MCX")
    elif eh_porta or eh_frontal_gaveta:
        rota.append("MPE")
        rota.append("MAR")

    if tem_tamponamento:
        rota.append("MAR")

    if tem_pintura:
        rota.append("PIN")
    if tem_tapecar:
        rota.append("TAP")
    if tem_eletrica:
        rota.append("MEL")

    rota.extend(["CQL", "EXP"])

    # Deduplicar preservando ordem
    rota_final: list[str] = []
    for etapa in rota:
        if etapa not in rota_final:
            rota_final.append(etapa)

    return " > ".join(rota_final)


# ---------------------------------------------------------------------------
# Plano de corte
# ---------------------------------------------------------------------------

def determinar_plano_dinabox(part: PartOperacional, module: ModuleOperacional, roteiro: str) -> str:
    """
    Determina o plano de corte (2 dígitos) equivalente ao antigo determinar_plano_de_corte().

    | Plano | Descrição                   |
    |-------|-----------------------------|
    | 01    | Pintura                     |
    | 02    | Lâmina / folha              |
    | 03    | Ripa corte (não usado aqui) |
    | 04    | Caixa de gaveta (MCX)       |
    | 05    | Duplagem (DUP)              |
    | 06    | Porta / frontal (MPE)       |
    | 07    | Painel / passagem           |
    | 10    | Pré-montagem                |
    | 11    | Padrão / demais             |
    """
    note = _note(part)
    name = _name(part)
    material_name = (
        part.material.name if part.material and part.material.name else ""
    ).lower()

    tem_pintura = "_pin_" in note or "pintura" in note or "PIN" in roteiro
    tem_lamina = (
        "_lamina_" in note
        or "lâmina" in material_name
        or "lamina" in material_name
        or "folha" in material_name
    )
    eh_painel = "_painel_" in note or "_passagem_" in note

    if tem_pintura:
        return "01"
    if tem_lamina:
        return "02"
    if "DUP" in roteiro:
        return "05"
    if eh_painel:
        return "07"
    if "MCX" in roteiro:
        return "04"
    if "MPE" in roteiro:
        return "06"
    return "11"
