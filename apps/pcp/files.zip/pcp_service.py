"""
pcp_service.py — refatorado para entrada via JSON Dinabox.

Abandona:
  - processar_arquivo_dinabox()  (leitura CSV/XLS + pandas)
  - consolidar_ripas()           (transformação de DataFrame)
  - gerar_xls_roteiro()          (saída XLS — o roteiro agora é dado estruturado)

Adiciona:
  - processar_projeto_dinabox()  — entrada: dict bruto do webhook/API Dinabox
"""
from __future__ import annotations

import uuid

from apps.integracoes.dinabox.schemas.dinabox_operacional import DinaboxProjectOperacional
from apps.pcp.models.processamento import ProcessamentoPCP
from apps.pcp.services.lote_service import LotePCPService


# ---------------------------------------------------------------------------
# Resumo do processamento (exposto à View)
# ---------------------------------------------------------------------------

def _montar_resumo(schema: DinaboxProjectOperacional) -> dict:
    total_modulos = schema.total_modules
    total_pecas = schema.total_parts
    total_furos = schema.total_holes
    total_rebordos = schema.total_edges_to_band

    return {
        "total_modulos": total_modulos,
        "total_pecas": total_pecas,
        "total_furos": total_furos,
        "total_rebordos": total_rebordos,
    }


# ---------------------------------------------------------------------------
# Entrada principal
# ---------------------------------------------------------------------------

def processar_projeto_dinabox(
    raw_json: dict,
    usuario=None,
    ordem_producao: str | None = None,
) -> dict:
    """
    Processa o JSON bruto de um projeto Dinabox e cria o LotePCP correspondente.

    Retorna um dicionário com as informações do processamento para exibição
    na interface (substitui o antigo retorno com xls_bytes e DataFrame).

    Raises:
        ValueError: se o JSON não puder ser validado pelo schema.
    """
    # 1. Validar e tipar via Pydantic
    schema = DinaboxProjectOperacional.model_validate(raw_json)

    # 2. Gerar PID único (8 chars, igual ao fluxo anterior)
    pid = str(uuid.uuid4())[:8]

    # 3. Nome do "arquivo" — usa a descrição do projeto como identificador
    nome_arquivo = f"dinabox_{schema.project_id}.json"

    # 4. Persistir ProcessamentoPCP (registro de auditoria)
    processamento = ProcessamentoPCP.objects.create(
        id=pid,
        nome_arquivo=nome_arquivo,
        lote=None,          # lote numérico não existe mais no fluxo JSON
        total_pecas=schema.total_parts,
        usuario=usuario if getattr(usuario, "is_authenticated", False) else None,
    )

    # 5. Criar hierarquia LotePCP via Service
    lote = LotePCPService.criar_lote_a_partir_de_schema(
        schema=schema,
        pid=pid,
        nome_arquivo=nome_arquivo,
        ordem_producao=ordem_producao,
    )

    # 6. Montar resumo para a View
    resumo = _montar_resumo(schema)

    # 7. Prévia das peças (primeiras 50, estruturada)
    previa: list[dict] = []
    for module in schema.woodwork:
        for part in module.parts:
            if len(previa) >= 50:
                break
            from apps.pcp.utils.roteiros_dinabox import (
                calcular_roteiro_dinabox,
                determinar_plano_dinabox,
            )
            roteiro = calcular_roteiro_dinabox(part, module)
            plano = determinar_plano_dinabox(part, module, roteiro)
            previa.append({
                "modulo": module.name,
                "peca_id": part.id,
                "descricao": part.name,
                "material": part.material.name if part.material else "",
                "largura": part.width,
                "altura": part.height,
                "espessura": part.thickness,
                "plano": plano,
                "roteiro": roteiro,
            })

    return {
        "pid": pid,
        "project_id": schema.project_id,
        "cliente": schema.project_customer_name,
        "total_pecas": schema.total_parts,
        "resumo": resumo,
        "previa": previa,
    }
