# Migração PCP — XLS/CSV → JSON Dinabox

## O que muda

| Antes | Depois |
|---|---|
| Entrada via upload de arquivo (CSV/XLS) | Entrada via JSON bruto do projeto Dinabox |
| `processar_arquivo_dinabox(uploaded_file, lote)` | `processar_projeto_dinabox(raw_json, usuario)` |
| Roteiro calculado via `pd.Series` (DataFrame) | Roteiro calculado via `PartOperacional` (Pydantic) |
| `LotePCPService.criar_lote_a_partir_de_dataframe()` | `LotePCPService.criar_lote_a_partir_de_schema()` |
| Retorna XLS para download | Retorna JSON estruturado com prévia |
| `lote` numérico obrigatório no form | `lote` numérico opcional (sem significado no fluxo JSON) |

## Arquivos entregues

```
apps/pcp/
├── utils/
│   └── roteiros_dinabox.py   ← NOVO  (substitui roteiros.py para entrada Dinabox)
├── services/
│   ├── lote_service.py       ← REFATORADO
│   └── pcp_service.py        ← REFATORADO
└── views.py                  ← REFATORADO
```

> `roteiros.py` e `ripas.py` **não são removidos** — ainda são usados por
> lotes históricos que chegaram via CSV. Podem ser depreciados após a migração
> completa dos processos.

## Mapeamento de lógica: CSV → Dinabox

| Critério (CSV) | Campo Dinabox |
|---|---|
| `DESCRIÇÃO DA PEÇA` contém "ripa" | *(sem ripas no fluxo JSON — peças vêm individualmente)* |
| `DUPLAGEM` preenchido | `module.type == "thickened"` OU `part.note` contém "duplagem" |
| `BORDA_FACE_*` preenchido | `part.edge_left/right/top/bottom.name` não-nulo |
| `FURO` preenchido | `part.holes.total_holes > 0` |
| `LOCAL` contém "porta" | `part.type == "door"` |
| `DESCRIÇÃO` contém "gaveta caixa" | `part.type == "drawer"` sem "contra frente"/"tampa" |
| `OBSERVAÇÃO` contém "_pin_" | `part.note` contém "_pin_" ou "pintura" |
| `MATERIAL DA PEÇA` contém "lâmina" | `part.material.name` contém "lâmina"/"folha" |

## Endpoint refatorado

**POST** `/pcp/processar/`

**Antes** (multipart/form-data):
```
arquivo = <file.csv>
lote    = 305
```

**Depois** (application/json):
```json
{
  "project_id": "12345",
  "project_customer_name": "Cliente XYZ",
  "woodwork": [ ... ]
}
```

Ou via FormData com compatibilidade:
```
json_data       = <JSON string do projeto Dinabox>
ordem_producao  = OP-2026-001   (opcional)
```

**Resposta** (igual à anterior, sem `nome_saida`):
```json
{
  "pid": "a1b2c3d4",
  "project_id": "12345",
  "cliente": "Cliente XYZ",
  "total_pecas": 166,
  "resumo": {
    "total_modulos": 16,
    "total_pecas": 166,
    "total_furos": 890,
    "total_rebordos": 142
  },
  "previa": [
    {
      "modulo": "Aéreo",
      "peca_id": "1966053",
      "descricao": "Base",
      "material": "Carvalho Poro - ARAUCO",
      "largura": 249,
      "altura": 1191,
      "espessura": 18,
      "plano": "11",
      "roteiro": "COR > BOR > USI > FUR > CQL > EXP"
    }
  ]
}
```

## Hierarquia de dados persistida

O JSON Dinabox não expõe "ambientes" (cômodos) diretamente.
O mapeamento atual usa a **descrição do projeto** como nome do ambiente único.

```
LotePCP (pid, cliente, project_id)
  └── AmbientePCP (nome = project_description)
        └── ModuloPCP (nome = module.name, codigo = module.mid)
              └── PecaPCP (roteiro, plano calculados no Service)
```

Quando o Dinabox expuser `project_groups`, basta atualizar `_nome_ambiente()`
em `lote_service.py` para refletir a hierarquia real — sem alterar models.

## Bipagem — sem alteração

`bipar_peca()`, `pcp_interface.py`, `RetornoBipagemService` e todos os
endpoints de bipagem permanecem **inalterados**.

## Compatibilidade com lotes históricos

- `pcp_download()` detecta se o lote tem `arquivo_saida` e serve o XLS se existir
- Lotes antigos gerados via CSV continuam acessíveis no histórico
- `ProcessamentoPCP.lote` (número do lote) fica `None` para lotes do fluxo JSON

## Dependências removidas

```python
# Não são mais necessárias no fluxo principal:
import pandas as pd
import xlwt
from apps.pcp.utils.ripas import consolidar_ripas
from apps.pcp.utils.roteiros import calcular_roteiro, determinar_plano_de_corte
```

Esses imports permanecem nos arquivos `ripas.py` e `roteiros.py` para
preservar lotes históricos, mas **não são chamados pelos services novos**.
