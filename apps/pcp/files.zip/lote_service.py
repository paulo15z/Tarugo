"""
LotePCPService — refatorado para API-First (Dinabox JSON).

Abandona a entrada via DataFrame/XLS e passa a consumir diretamente o schema
DinaboxProjectOperacional, calculando roteiro e plano de corte internamente.

Mantém:
  - bipar_peca()           — intacto
  - hierarquia DB          — LotePCP > AmbientePCP > ModuloPCP > PecaPCP

Remove:
  - criar_lote_a_partir_de_dataframe()
  - _build_lote_input() (dependia de pd.DataFrame)

Adiciona:
  - criar_lote_a_partir_de_schema()  — entrada principal nova
"""
from __future__ import annotations

from django.db import transaction

from apps.integracoes.dinabox.schemas.dinabox_operacional import (
    DinaboxProjectOperacional,
    ModuleOperacional,
    PartOperacional,
)
from apps.pcp.models.lote import AmbientePCP, LotePCP, ModuloPCP, PecaPCP
from apps.pcp.utils.roteiros_dinabox import (
    calcular_roteiro_dinabox,
    determinar_plano_dinabox,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _codigo_peca(part: PartOperacional) -> str:
    """Retorna o melhor identificador único da peça."""
    return part.id or part.ref or part.code_a or part.code_b or ""


def _codigo_modulo(module: ModuleOperacional) -> str:
    return module.mid or module.ref or module.id or ""


def _nome_ambiente(project: DinaboxProjectOperacional) -> str:
    """
    O JSON do Dinabox não tem hierarquia 'ambiente' explícita — usamos a
    descrição do projeto como nome do ambiente único.
    Se no futuro o Dinabox expuser project_groups, este helper pode
    ser atualizado para refletir a hierarquia real.
    """
    return project.project_description or project.project_id


# ---------------------------------------------------------------------------
# Service principal
# ---------------------------------------------------------------------------

class LotePCPService:
    """Regras de negócio do PCP: criação de lote e bipagem."""

    # ------------------------------------------------------------------
    # ENTRADA NOVA — via schema Dinabox
    # ------------------------------------------------------------------

    @staticmethod
    @transaction.atomic
    def criar_lote_a_partir_de_schema(
        schema: DinaboxProjectOperacional,
        pid: str,
        nome_arquivo: str,
        ordem_producao: str | None = None,
    ) -> LotePCP:
        """
        Persiste a hierarquia LotePCP a partir do schema operacional do Dinabox.

        Fluxo:
          DinaboxProjectOperacional
            └── woodwork[]  (ModuleOperacional)
                  └── parts[]  (PartOperacional)
                        └── calcular_roteiro_dinabox() + determinar_plano_dinabox()
                              └── PecaPCP

        O projeto Dinabox não possui hierarquia 'ambiente' explícita.
        Mapeamos: projeto → 1 AmbientePCP; módulo → ModuloPCP; peça → PecaPCP.
        """
        lote = LotePCP.objects.create(
            pid=pid,
            arquivo_original=nome_arquivo,
            cliente_nome=schema.project_customer_name,
            cliente_id_projeto=schema.project_customer_id,
            ordem_producao=ordem_producao,
        )

        # Um ambiente por projeto (nome = descrição do projeto)
        ambiente = AmbientePCP.objects.create(
            lote=lote,
            nome=_nome_ambiente(schema),
        )

        for module in schema.woodwork:
            modulo_db = ModuloPCP.objects.create(
                ambiente=ambiente,
                nome=module.name,
                codigo_modulo=_codigo_modulo(module),
            )

            for part in module.parts:
                roteiro = calcular_roteiro_dinabox(part, module)
                plano = determinar_plano_dinabox(part, module, roteiro)

                # Dimensões: Dinabox entrega em mm (inteiros)
                PecaPCP.objects.create(
                    modulo=modulo_db,
                    referencia_bruta=part.ref or part.id,
                    codigo_modulo=_codigo_modulo(module),
                    codigo_peca=_codigo_peca(part),
                    descricao=part.name,
                    local=None,          # Dinabox não expõe campo LOCAL
                    material=(
                        part.material.name if part.material else None
                    ),
                    codigo_material=(
                        part.material.id if part.material else None
                    ),
                    comprimento=part.height,    # Dinabox: height = comprimento
                    largura=part.width,         # Dinabox: width  = largura
                    espessura=part.thickness,
                    metro_quadrado=None,        # calculado externamente se necessário
                    quantidade_planejada=part.count,
                    atributos_tecnicos=LotePCPService._atributos_tecnicos(part, module),
                    roteiro=roteiro,
                    plano=plano,
                    observacoes=(part.note or "").strip() or None,
                    lote_dinabox=schema.project_id,
                    id_peca_dinabox=part.id,
                )

        return lote

    # ------------------------------------------------------------------
    # Atributos técnicos (substituem o JSONField antigo)
    # ------------------------------------------------------------------

    @staticmethod
    def _atributos_tecnicos(part: PartOperacional, module: ModuleOperacional) -> dict:
        """
        Persiste os dados técnicos da peça que não cabem em campos escalares.
        Mantém a mesma chave 'atributos_tecnicos' do modelo.
        """
        edges: dict[str, str | None] = {}
        for side in ("left", "right", "top", "bottom"):
            edge = getattr(part, f"edge_{side}", None)
            edges[side] = edge.name if edge else None

        holes_count = part.holes.total_holes if part.holes else 0

        return {
            "type": part.type,
            "entity": part.entity,
            "module_type": module.type,
            "has_holes": holes_count > 0,
            "total_holes": holes_count,
            "edges": edges,
            "note": (part.note or "").strip(),
            "pre_assembly": module.pre_assembly or False,
        }

    # ------------------------------------------------------------------
    # Bipagem — inalterado
    # ------------------------------------------------------------------

    @staticmethod
    def bipar_peca(peca_id, quantidade: int, usuario: str | None = None) -> PecaPCP:
        """Bipagem simples: só atualiza PCP."""
        peca = PecaPCP.objects.get(id=peca_id)
        peca.quantidade_produzida += quantidade
        if peca.quantidade_produzida >= peca.quantidade_planejada:
            peca.status = "finalizado"
        else:
            peca.status = "em_producao"
        peca.save(update_fields=["quantidade_produzida", "status"])
        return peca
