"""
Views do app PCP — refatoradas para entrada via JSON Dinabox.

Mantém:
  - pcp_index()           — renderiza template
  - pcp_historico()       — lista processamentos
  - pcp_liberar/bloquear/reabrir/remover/viagem — ciclo de vida do lote
  - pcp_download()        — não aplica mais (sem XLS), mantido por compatibilidade
  - pcp_retorno_lote()    — retorno de bipagem
  - pcp_retorno_relatorio()

Remove:
  - lógica de leitura de arquivo (request.FILES)
  - geração de XLS

Adiciona:
  - pcp_processar()       — agora recebe JSON bruto no body (application/json)
"""
from __future__ import annotations

import json

from django.contrib.auth.decorators import login_required
from django.http import Http404, HttpResponse, JsonResponse
from django.shortcuts import render
from django.views.decorators.http import require_GET, require_POST

from apps.pcp.models.processamento import ProcessamentoPCP
from apps.pcp.services.historico_service import HistoricoPCPService
from apps.pcp.services.pcp_interface import (
    bloquear_lote_bipagem,
    liberar_lote_para_bipagem,
    reabrir_lote_bipagem,
)
from apps.pcp.services.pcp_service import processar_projeto_dinabox
from apps.pcp.services.retorno_bipagem_service import RetornoBipagemService


# ---------------------------------------------------------------------------
# Permissões
# ---------------------------------------------------------------------------

def _user_pode_gerenciar_pcp(user) -> bool:
    if not user or not user.is_authenticated:
        return False
    if user.is_superuser or user.is_staff:
        return True
    return user.groups.filter(name__in=["PCP", "TI"]).exists()


def _json_forbidden():
    return JsonResponse(
        {"erro": "Somente PCP, TI ou admin podem executar esta ação."},
        status=403,
    )


# ---------------------------------------------------------------------------
# Interface
# ---------------------------------------------------------------------------

@login_required
def pcp_index(request):
    return render(request, "pcp/index.html", {
        "pode_gerenciar_pcp": _user_pode_gerenciar_pcp(request.user),
    })


# ---------------------------------------------------------------------------
# Processamento — agora via JSON Dinabox
# ---------------------------------------------------------------------------

@require_POST
@login_required
def pcp_processar(request):
    """
    Recebe o JSON bruto de um projeto Dinabox e cria o LotePCP.

    Aceita dois formatos:
      1. Content-Type: application/json  → body direto
      2. Content-Type: multipart/form-data → campo 'json_data' (compatibilidade
         com interfaces que ainda usam FormData)

    Não recebe mais arquivos XLS/CSV.
    """
    if not _user_pode_gerenciar_pcp(request.user):
        return _json_forbidden()

    # Extrair o JSON bruto
    content_type = request.content_type or ""
    raw_json: dict | None = None

    if "application/json" in content_type:
        try:
            raw_json = json.loads(request.body)
        except (json.JSONDecodeError, ValueError):
            return JsonResponse({"erro": "JSON inválido no body da requisição."}, status=400)
    else:
        # Compatibilidade FormData: campo 'json_data'
        json_str = request.POST.get("json_data", "").strip()
        if not json_str:
            return JsonResponse(
                {"erro": "Envie o JSON do projeto Dinabox no body (application/json) "
                         "ou no campo 'json_data' do form."},
                status=400,
            )
        try:
            raw_json = json.loads(json_str)
        except (json.JSONDecodeError, ValueError):
            return JsonResponse({"erro": "JSON inválido no campo 'json_data'."}, status=400)

    ordem_producao = request.POST.get("ordem_producao") or None

    try:
        resultado = processar_projeto_dinabox(
            raw_json=raw_json,
            usuario=request.user,
            ordem_producao=ordem_producao,
        )
        return JsonResponse(resultado)
    except ValueError as exc:
        return JsonResponse({"erro": f"Erro de validação: {exc}"}, status=400)
    except Exception as exc:
        return JsonResponse({"erro": str(exc)}, status=500)


# ---------------------------------------------------------------------------
# Ciclo de vida do lote (bipagem)
# ---------------------------------------------------------------------------

@require_POST
@login_required
def pcp_liberar(request, pid):
    if not _user_pode_gerenciar_pcp(request.user):
        return _json_forbidden()
    try:
        resultado = liberar_lote_para_bipagem(pid, usuario=request.user)
        if not resultado.get("sucesso"):
            return JsonResponse({"erro": resultado.get("mensagem")}, status=400)
        return JsonResponse(resultado)
    except Exception as exc:
        return JsonResponse({"erro": str(exc)}, status=500)


@require_POST
@login_required
def pcp_bloquear(request, pid):
    if not _user_pode_gerenciar_pcp(request.user):
        return _json_forbidden()
    motivo = request.POST.get("motivo", "") or request.GET.get("motivo", "")
    resultado = bloquear_lote_bipagem(pid, motivo=motivo)
    return JsonResponse(resultado, status=200 if resultado["sucesso"] else 404)


@require_POST
@login_required
def pcp_reabrir(request, pid):
    if not _user_pode_gerenciar_pcp(request.user):
        return _json_forbidden()
    resultado = reabrir_lote_bipagem(pid)
    return JsonResponse(resultado, status=200 if resultado["sucesso"] else 404)


# ---------------------------------------------------------------------------
# Ciclo de vida — viagem/expedição
# ---------------------------------------------------------------------------

@require_POST
@login_required
def pcp_liberar_viagem(request, pid):
    if not _user_pode_gerenciar_pcp(request.user):
        return _json_forbidden()
    try:
        from django.utils import timezone

        lote = ProcessamentoPCP.objects.get(id=pid)
        lote.liberado_para_viagem = True
        lote.data_liberacao_viagem = timezone.now()
        lote.save(update_fields=["liberado_para_viagem", "data_liberacao_viagem"])
        return JsonResponse({
            "sucesso": True,
            "mensagem": "Lote liberado para viagem.",
            "data_liberacao_viagem": lote.data_liberacao_viagem.isoformat(),
        })
    except ProcessamentoPCP.DoesNotExist:
        return JsonResponse({"erro": "Lote não encontrado."}, status=404)
    except Exception as exc:
        return JsonResponse({"erro": str(exc)}, status=500)


@require_POST
@login_required
def pcp_remover(request, pid):
    if not _user_pode_gerenciar_pcp(request.user):
        return _json_forbidden()
    try:
        motivo = (
            request.POST.get("motivo", "").strip()
            or request.GET.get("motivo", "").strip()
        )
        resultado = HistoricoPCPService.remover_processamento(
            pid=pid, motivo=motivo, usuario=request.user
        )
        if resultado.get("sucesso"):
            return JsonResponse(resultado, status=200)
        return JsonResponse(
            {"erro": resultado.get("mensagem", "Não foi possível remover o lote."), **resultado},
            status=400,
        )
    except Exception as exc:
        return JsonResponse({"erro": str(exc)}, status=500)


# ---------------------------------------------------------------------------
# Histórico e retorno
# ---------------------------------------------------------------------------

@require_GET
@login_required
def pcp_historico(request):
    if not _user_pode_gerenciar_pcp(request.user):
        return _json_forbidden()
    registros = ProcessamentoPCP.objects.order_by("-criado_em")[:50]
    data = [
        {
            "id": r.id,
            "nome_arquivo": r.nome_arquivo,
            "lote": r.lote,
            "total_pecas": r.total_pecas,
            "data": r.criado_em.isoformat(),
            "liberado": r.liberado_para_bipagem,
            "data_liberacao": r.data_liberacao.isoformat() if r.data_liberacao else None,
            "liberado_viagem": r.liberado_para_viagem,
            "data_liberacao_viagem": (
                r.data_liberacao_viagem.isoformat() if r.data_liberacao_viagem else None
            ),
            "pode_remover": _user_pode_gerenciar_pcp(request.user),
        }
        for r in registros
    ]
    return JsonResponse(data, safe=False)


@require_GET
@login_required
def pcp_retorno_lote(request, pid):
    if not _user_pode_gerenciar_pcp(request.user):
        return _json_forbidden()
    retorno = RetornoBipagemService.obter_retorno_lote(pid=pid)
    if not retorno:
        return JsonResponse({"erro": "Lote não encontrado para retorno."}, status=404)
    return JsonResponse(retorno)


@require_GET
@login_required
def pcp_retorno_relatorio(request, pid):
    if not _user_pode_gerenciar_pcp(request.user):
        return HttpResponse("Acesso negado.", status=403)
    csv_content = RetornoBipagemService.gerar_relatorio_csv(pid=pid)
    if csv_content is None:
        raise Http404("Lote não encontrado para relatório.")
    processamento = ProcessamentoPCP.objects.filter(id=pid).only("lote").first()
    lote_str = processamento.lote if processamento and processamento.lote else pid
    filename = f"retorno_bipagem_lote_{lote_str}.csv"
    response = HttpResponse(csv_content, content_type="text/csv; charset=utf-8")
    response["Content-Disposition"] = f'attachment; filename="{filename}"'
    return response


# ---------------------------------------------------------------------------
# Download — mantido para compatibilidade (retorna 404 graciosamente)
# ---------------------------------------------------------------------------

@require_GET
@login_required
def pcp_download(request, pid):
    """
    No fluxo JSON não há mais XLS gerado.
    Mantido na URL para não quebrar links existentes no histórico.
    """
    if not _user_pode_gerenciar_pcp(request.user):
        return HttpResponse("Acesso negado.", status=403)
    try:
        processamento = ProcessamentoPCP.objects.get(id=pid)
    except ProcessamentoPCP.DoesNotExist:
        raise Http404("Processamento não encontrado.")

    if not processamento.arquivo_saida:
        return JsonResponse(
            {"erro": "Este lote foi gerado via JSON Dinabox e não possui arquivo XLS."},
            status=404,
        )

    # Compatibilidade: lotes antigos ainda têm XLS
    try:
        arquivo = processamento.arquivo_saida.open("rb")
    except FileNotFoundError:
        raise Http404("Arquivo não encontrado no servidor.")

    from django.http import FileResponse
    nome = processamento.arquivo_saida.name.split("/")[-1]
    return FileResponse(arquivo, as_attachment=True, filename=nome)
